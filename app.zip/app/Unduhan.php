<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unduhan extends Model
{
    protected $table = 'unduhan';
    protected $guarded = array('id');

}
