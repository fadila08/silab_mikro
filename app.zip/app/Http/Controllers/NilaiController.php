<?php

namespace App\Http\Controllers;

use App\Nilai;
use Illuminate\Http\Request;

class NilaiController extends Controller
{
    public function index (Nilai $nilai) {
        return response()->json($nilai->all());
    }
    
    public function store (Request $request, Nilai $nilai) {
        
    }
    
    public function update (Request $request, Nilai $nilai) {
        
    }
    
    public function show (Nilai $nilai) {
        
    }
    
    public function destroy (Nilai $nilai) {
        
    }
}
