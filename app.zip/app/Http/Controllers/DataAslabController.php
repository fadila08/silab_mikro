<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Transformers\InsertDataUserTransformer;
use App\Transformers\UserTransformer;
use App\Transformers\ViewUserTransformer;
use Auth;
use JWTAuth;
use App\User;

class DataAslabController extends Controller
{
    public function __contruct(Request $request)
    {
        // $this->middleware('aslab')
    }

    public function index(User $user)
    {
        $user = $user->where('id_roles', '=', 3)->get(); 

        return fractal()
            ->collection($user)
            ->transformWith(new ViewUserTransformer)
            ->toArray();
    }

    public function show(User $user)
    {
        return fractal()
            ->item($user)
            ->transformWith(new UserTransformer)
            ->toArray();
    }

    public function store(Request $request, User $user)
    {
        $this->validate($request, [
            'nama' => 'required',
            'nomor_induk' => 'required|unique:users'
        ]);

        $user = $user->create([
            'username' => $request->nomor_induk,
            'password' => Hash::make($request->nomor_induk),
            'nama' => ucwords(strtolower($request->nama)),
            'nomor_induk' => $request->nomor_induk,
            'email' => $request->email,
            'nomor_whatsapp' => $request->nomor_whatsapp,
            'id_roles' => 3,
            'api_token' => bcrypt($request->nomor_induk),
        ]);

        $response = fractal()
        ->item($user)
        ->transformWith(new InsertDataUserTransformer)
        ->addMeta([
            'token' => JWTAuth::fromUser($user),
        ])
        ->toArray();
                    
        return response()->json($response, 201);

    }

    public function update(Request $request, User $user)
    {
        $user->username = $request->nomor_induk;
        $user->nama = $request->nama;
        $user->nomor_induk = $request->nomor_induk;
        $user->email = $request->email;
        $user->nomor_whatsapp = $request->nomor_whatsapp;

        $user->save();

        return fractal()
            ->item($user)
            ->transformWith(new UserTransformer)
            ->toArray();
    }

    public function destroy(Request $request, User $user)
    {
        $user->delete();

        return response()->json([
            'message' => 'data sudah terhapus',
        ]);
    }
}
